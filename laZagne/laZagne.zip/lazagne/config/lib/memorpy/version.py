#!/usr/bin/env python
# -*- coding: UTF8 -*-

version=(1,7)
version_string="%s.%s"%version

